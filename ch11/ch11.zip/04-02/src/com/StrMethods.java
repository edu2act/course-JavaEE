package com;

public class StrMethods {
	public static String upper(String x) {
		return x.toUpperCase();
	}

	public static int length(String x) {
		return x.length();
	}
}
