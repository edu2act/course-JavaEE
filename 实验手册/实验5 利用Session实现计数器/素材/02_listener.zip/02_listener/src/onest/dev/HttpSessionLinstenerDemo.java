package onest.dev;

import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

/**
 * Application Lifecycle Listener implementation class HttpSessionLinstenerDemo
 *
 */
public class HttpSessionLinstenerDemo implements HttpSessionListener {

    /**
     * Default constructor. 
     */
    public HttpSessionLinstenerDemo() {
        // TODO Auto-generated constructor stub
    }

	/**
     * @see HttpSessionListener#sessionCreated(HttpSessionEvent)
     */
    public void sessionCreated(HttpSessionEvent arg0)  { 
         // TODO Auto-generated method stub
    	 int onlineNum = (Integer) arg0.getSession().getServletContext().getAttribute("onlineNum");
    	    arg0.getSession().getServletContext().setAttribute("onlineNum", ++onlineNum);
      }

	/**
     * @see HttpSessionListener#sessionDestroyed(HttpSessionEvent)
     */
    public void sessionDestroyed(HttpSessionEvent arg0)  { 
         // TODO Auto-generated method stub
        int onlineNum = (Integer) arg0.getSession().getServletContext().getAttribute("onlineNum");
        arg0.getSession().getServletContext().setAttribute("onlineNum", --onlineNum);
      
        String name = (String) arg0.getSession().getAttribute("membername");
        
        if(name != null)
        {
        	int onlineMemberNum = (Integer) arg0.getSession().getServletContext().getAttribute("onlineMemberNum");
        	arg0.getSession().getServletContext().setAttribute("onlineMemberNum", --onlineMemberNum);
        }
    }
	
}
